//
// Created by Abel Chils Trabanco (NIA: 718997) and Jorge Aznar López (NIA: 721556)
//

#ifndef PRACTICA2ALGORITMIABASICA_DEFINES_H
#define PRACTICA2ALGORITMIABASICA_DEFINES_H

#include <cstring>
using namespace std;

// Path del fichero que contiene la entrada
const string input_path = "entrada.txt";

// Path del fichero que contiene la salida/resultado del algoritmo
const string output_path = "salida.txt";

#endif //PRACTICA2ALGORITMIABASICA_DEFINES_H
